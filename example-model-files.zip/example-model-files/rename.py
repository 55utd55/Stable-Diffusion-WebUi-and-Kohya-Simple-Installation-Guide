import os

isim = str(0)

current_dir = os.getcwd()

files = os.listdir(current_dir)

for file in files:
    if os.path.basename(__file__) != file:
        (file_name, file_extension) = os.path.splitext(file)
        new_name = isim + str(files.index(file)) + file_extension
        os.rename(file, new_name)